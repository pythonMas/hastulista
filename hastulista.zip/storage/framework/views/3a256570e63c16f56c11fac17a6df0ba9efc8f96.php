<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>