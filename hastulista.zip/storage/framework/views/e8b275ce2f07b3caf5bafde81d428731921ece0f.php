
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="top_bar_contact_item">
        <div class="top_bar_icon">
            <?php if($menu_item->title === 'Facebook'): ?>
                <a href="<?php echo e($menu_item->link()); ?>" target="_blank">
                    <i class="fab fa-facebook fa-lg"></i>
                </a>
            <?php elseif($menu_item->title === 'Twitter'): ?>
                <a href="<?php echo e($menu_item->link()); ?>">
                    <i class="fab fa-twitter fa-lg"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/partials/menus/social-menus.blade.php ENDPATH**/ ?>