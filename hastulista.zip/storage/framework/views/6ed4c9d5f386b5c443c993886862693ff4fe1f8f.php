<?php $__env->startSection('title', 'Mi perfil'); ?>

<?php $__env->startSection('extra-css'); ?>


<link rel="stylesheet" href="<?php echo e(asset('css/plantilla/main_styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class=" row justify-content-around">

            <div class="col-md-6 offset-md-3 col-sm-12 ">
                <h1 class="text-md-center ">Mi perfil</h1>
                <?php if(session()->has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success_message')); ?>

                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('users.update')); ?>">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="input-group my-3">

                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class=" input-group-addon"><i class="fa fa-user "></i></span>
                            </div>
                        </div>


                        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="name" value="<?php echo e(old('name', $user->name)); ?>"
                               required autocomplete="name" autofocus placeholder="Nombre completo">

                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <div class="input-group my-3">

                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class=" input-group-addon"><i class="fas fa-envelope"></i></span>
                            </div>
                        </div>


                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                               required autocomplete="email" placeholder="Dirección de correo electrónico">

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <div class="input-group my-3">

                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class=" input-group-addon"><i class="fas fa-lock"></i></span>
                            </div>
                        </div>

                        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="password"
                               autocomplete="new-password" placeholder="Contraseña">
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div>Deje la contraseña en blanco para mantener la contraseña actual</div>

                    <div class="input-group my-3">

                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <span class=" input-group-addon"><i class="fas fa-check-circle"></i></span>
                            </div>
                        </div>

                        <input id="password-confirm" type="password" class="form-control py-4" name="password_confirmation" autocomplete="new-password"
                               placeholder="Confirmar contraseña">
                    </div>


                    <div class="form-group row mb-0">
                        <div class="col-12 ">
                            <button type="submit" class="btn btn-primary btn-block btn-lg">
                                <?php echo e(__('Actualizar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/my-profile.blade.php ENDPATH**/ ?>