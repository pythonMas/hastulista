<?php $__env->startSection('title', 'Gracias'); ?>

<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/main_styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/responsive.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class', 'sticky-footer'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container p-5 m-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <h1 class="text-center">Gracias por <br> Su pedido!</h1>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-4">
                <p class="text-center">Su pedido ha sido enviado</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-4">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-lg btn-block btn-outline-primary">Página de inicio</a>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/thankyou.blade.php ENDPATH**/ ?>