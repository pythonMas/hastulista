<?php echo e($slot); ?>

<?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>