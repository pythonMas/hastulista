<?php if($paginator->hasPages()): ?>
    <div class="shop_page_nav d-flex flex-row">
        
        <?php if($paginator->onFirstPage()): ?>
            <a class="disabled d-flex flex-column align-items-center justify-content-center"> <i class="fas fa-chevron-left"></i> </a>

        <?php else: ?>
            <a class="page_prev d-flex flex-column align-items-center justify-content-center" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">
                <i class="fas fa-chevron-left"></i>
            </a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <ul class="page_nav d-flex flex-row">
                    <li><a class="icon item disabled" aria-disabled="true"><?php echo e($element); ?></a></li>
                </ul>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <ul class="page_nav d-flex flex-row">
                            <li><a class="item active" href="<?php echo e($url); ?>" aria-current="page"><?php echo e($page); ?></a></li>
                        </ul>

                    <?php else: ?>
                        <ul class="page_nav d-flex flex-row">
                            <li><a class="item" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        </ul>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>

                <a class="page_next d-flex flex-column align-items-center justify-content-center" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">
                    <i class="fas fa-chevron-right"></i>
                </a>

        <?php else: ?>
            <a class="disabled d-flex flex-column align-items-center justify-content-center"> <i class="fas fa-chevron-right"></i> </a>

        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\User\PhpstormProjects\lista-ecommerce\resources\views/vendor/pagination/pagination.blade.php ENDPATH**/ ?>