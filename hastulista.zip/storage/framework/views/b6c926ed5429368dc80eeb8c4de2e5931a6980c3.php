<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/main_styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/responsive.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-between">
            <div class="col-md-5">
                <div>
                    <form action="<?php echo e(route('checkout.store')); ?>" method="POST" id="payment-form">
                        <?php echo e(csrf_field()); ?>

                        <h3>Detalles de facturación</h3>

                        <div class="form-group">
                            <label for="email">Email Address</label>

                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>

                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address')); ?>" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <input type="text" class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="province">Province</label>
                                    <input type="text" class="form-control" id="province" name="province" value="<?php echo e(old('province')); ?>" required>
                                </div>
                            </div>

                        </div> <!-- end half-form -->

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="postalcode">Postal Code</label>
                                    <input type="text" class="form-control" id="postalcode" name="postalcode" value="<?php echo e(old('postalcode')); ?>" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>" required>
                                </div>
                            </div>

                        </div> <!-- end half-form -->

                        <button type="submit" id="complete-order" class="btn btn-lg btn-block btn-outline-primary">Orden completa</button>

                    </form>

                </div>
            </div>
            <div class="col-md-6">
                <div class="checkout-table-container">
                    <h3>Su pedido</h3>

                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row justify-content-between">
                            <div class="col-md-3">
                                <img src="<?php echo e(asset('storage/'.$item->options->image)); ?>" alt="item" class="img-fluid" width="133" height="133">
                            </div>
                            <div class="col-md-3">
                                <div>
                                    <h5><strong>Producto:</strong> <span><?php echo e($item->name); ?></span></h5>
                                    <h5><strong>Descripción:</strong> <span><?php echo e($item->options->slug); ?></span></h5>
                                    <h5><strong>Precio:</strong> <span>S/<?php echo e($item->price); ?></span></h5>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <strong class="mt-5">Cantidad</strong>
                                <span class="rounded p-4"><?php echo e($item->qty); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>


                    <div class="row justify-content-between mx-5">
                        <h5><strong>Subtotal:</strong></h5> <h5><span>S/<?php echo e(Cart::subtotal()); ?></span></h5>
                    </div>
                    <div class="row justify-content-between mx-5">
                        <h5><strong>Impuesto:</strong></h5> <h5><span>S/<?php echo e(Cart::tax()); ?></span></h5>
                    </div>
                    <div class="row justify-content-between mx-5">
                        <h5><strong>Total:</strong></h5> <h5><span>S/<?php echo e(Cart::total()); ?></span></h5>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\PhpstormProjects\lista-ecommerce\resources\views/checkout.blade.php ENDPATH**/ ?>