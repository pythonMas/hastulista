<?php $__env->startComponent('mail::message'); ?>
    # Orden recibida

    Gracias por su orden.

    **Id de Orden:** <?php echo e($order->id); ?>


    **Email:** <?php echo e($order->billing_email); ?>


    **Nombre:** <?php echo e($order->billing_name); ?>


    **Total a pagar:** $<?php echo e(round($order->billing_total, 2)); ?>


    **Artículos ordenados**

    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        Nombre: <?php echo e($product->name); ?> <br>
        Precio: $<?php echo e(round($product->price, 2)); ?> <br>
        Cantidad: <?php echo e($product->pivot->quantity); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    Puede obtener más detalles sobre su pedido ingresando a nuestro sitio web.

    <?php $__env->startComponent('mail::button', ['url' => config('app.url'), 'color' => 'green']); ?>
        Ir al sitio web
    <?php echo $__env->renderComponent(); ?>

    Gracias de nuevo por elegirnos.

    Saludos,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/emails/orders/placed.blade.php ENDPATH**/ ?>