<?php $__env->startSection('title', $product->name ); ?>

<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/product_styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/product_responsive.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Single Product -->

    <div class="single_product">
        <div class="container">

            <div class="row justify-content-center">
                <?php if(session()->has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success_message')); ?>

                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>

            <div class="row">
                <!-- Images -->
                <div class="col-lg-2 order-lg-1 order-2">

                    <?php if($product->images): ?>
                        <ul class="image_list">
                        <?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li data-image="<?php echo e(productImage($image)); ?>"><img src="<?php echo e(productImage($image)); ?>" alt=""></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                </div>

                <!-- Selected Image -->
                <div class="col-lg-5 order-lg-2 order-1">
                    <div class="image_selected img-fluid"><img class="img-fluid" src="<?php echo e(productImage($product->image)); ?>" alt=""></div>
                </div>

                <!-- Description -->
                <div class="col-lg-5 order-3">
                    <div class="product_description">
                        <div class="product_name"><?php echo e($product->name); ?></div>
                        <div class="product_text"><p><?php echo e($product->description); ?></p></div>
                        <div><?php echo $stockLevel; ?></div>
                        <div class="order_info d-flex flex-row">
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST"><?php echo e(csrf_field()); ?>

                                <div class="clearfix" style="z-index: 1000;">

                                    <!-- Product Quantity -->
                                    <div class="product_quantity clearfix">
                                        <span>Cantidad: </span>
                                        <input id="quantity_input" name="qty" type="text" pattern="[0-9]*" value="1" required  data-productQuantity="<?php echo e($product->quantity); ?>">
                                        <div class="quantity_buttons">
                                            <div id="quantity_inc_button" class="quantity_inc quantity_control"><i class="fas fa-chevron-up"></i></div>
                                            <div id="quantity_dec_button" class="quantity_dec quantity_control"><i class="fas fa-chevron-down"></i></div>
                                        </div>
                                    </div>

                                </div>

                                <div class="product_price"><?php echo e($product->presentPrice()); ?></div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                <input type="hidden" name="slug" value="<?php echo e($product->slug); ?>">
                                <input type="hidden" name="image" value="<?php echo e($product->image); ?>">

                                <?php if($product->quantity > 0): ?>
                                    <div class="button_container">
                                        <button type="submit" class="btn btn-primary">Añadir a la cesta</button>
                                        <div class="product_fav"><i class="fas fa-heart"></i></div>
                                    </div>
                                <?php else: ?>
                                    <div class="button_container">
                                        <h4>No está disponible</h4>
                                    </div>
                                <?php endif; ?>


                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php echo $__env->make('partials.might-like', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/plantilla/product_custom.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/product.blade.php ENDPATH**/ ?>