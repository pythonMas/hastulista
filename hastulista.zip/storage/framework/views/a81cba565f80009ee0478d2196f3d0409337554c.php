<ul class="standard_dropdown main_nav_dropdown">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($menu_item->link()); ?>"><?php echo e($menu_item->title); ?> <i class="fas fa-chevron-down"></i> </a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\Users\vela_\PhpstormProjects\lista-ecommerce\resources\views/partials/menus/main.blade.php ENDPATH**/ ?>