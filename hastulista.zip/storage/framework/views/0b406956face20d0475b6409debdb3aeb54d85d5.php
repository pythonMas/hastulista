<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Lista Ecommerce | <?php echo $__env->yieldContent('title', ''); ?></title>

    <link href="/img/favicon.ico" rel="SHORTCUT ICON" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/fontawesome-all.css')); ?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla.css')); ?>">

    <?php echo $__env->yieldContent('extra-css'); ?>
</head>


<body class="<?php echo $__env->yieldContent('body-class', ''); ?>">

    <div class="super_container">

        <div id="app">
            <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <?php if(auth()->guard(session()->put('previousUrl', url()->current()))->guest()): ?>
                <?php echo $__env->make('partials.auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plantilla.js')); ?>"></script>
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>
</html>
<?php /**PATH C:\Users\vela_\PhpstormProjects\lista-ecommerce\resources\views/layout.blade.php ENDPATH**/ ?>