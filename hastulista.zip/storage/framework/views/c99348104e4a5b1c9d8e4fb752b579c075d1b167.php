<?php $__env->startSection('title', 'Mi pedido'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/plantilla/cart_styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="cart_section">
        <div class="container">
            <div class="row">

                <div class="col-lg-10 offset-lg-1">
                    <h1 class="text-md-center ">Mi pedido</h1>
                    <?php if(session()->has('success_message')): ?>
                        <div class="alert alert-success text-center">
                            <?php echo e(session()->get('success_message')); ?>

                        </div>
                    <?php endif; ?>


                    <div class="cart_container">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="cart_items">
                            <ul class="cart_list">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cart_item clearfix">
                                        <div class="cart_item_image">
                                            <img  src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="<?php echo e($product->image); ?>">
                                        </div>
                                        <div class="cart_item_info d-flex flex-md-row flex-column justify-content-between">
                                            <div class="cart_item_name cart_info_col">
                                                <div class="cart_item_title">Producto</div>
                                                <div class="cart_item_text"><?php echo e($product->name); ?></div>
                                            </div>
                                            <div class="cart_item_quantity cart_info_col">
                                                <div class="cart_item_title">Cantidad</div>
                                                <div class="cart_item_text"><?php echo e($product->pivot->quantity); ?></div>
                                            </div>
                                            <div class="cart_item_price cart_info_col">
                                                <div class="cart_item_title">Precio</div>
                                                <div class="cart_item_text">S/<?php echo e($product->price); ?></div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/my-order.blade.php ENDPATH**/ ?>