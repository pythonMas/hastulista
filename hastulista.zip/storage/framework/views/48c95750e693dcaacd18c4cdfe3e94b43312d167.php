<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/cart_styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plantilla/cart_responsive.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Cart -->
    <div class="cart_section">
        <div class="container">
            <div class="row">

                <div class="col-lg-10 offset-lg-1">

                    <?php if(session()->has('success_message')): ?>
                        <div class="alert alert-success text-center">
                            <?php echo e(session()->get('success_message')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if( Cart::count() > 0): ?>
                    <div class="cart_container">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <h2><?php echo e(Cart::count()); ?> artículo(s) en la cesta de compra</h2>
                        <div class="cart_items">
                            <ul class="cart_list">
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cart_item clearfix">
                                        <div class="cart_item_image">
                                            <img src="<?php echo e(productImage($item->options->image)); ?>" alt="<?php echo e($item->name); ?>">
                                            
                                        </div>
                                        <div class="cart_item_info d-flex flex-md-row flex-column justify-content-between">
                                            <div class="cart_item_name cart_info_col">
                                                <div class="cart_item_title">Producto</div>
                                                <div class="cart_item_text"><?php echo e($item->name); ?></div>
                                            </div>
                                            <div class="cart_item_quantity cart_info_col">
                                                <div class="cart_item_title">Cantidad</div>
                                                <div class="cart_item_text"><?php echo e($item->qty); ?></div>
                                            </div>
                                            <div class="cart_item_price cart_info_col">
                                                <div class="cart_item_title">Precio</div>
                                                <div class="cart_item_text">S/<?php echo e($item->price); ?></div>
                                            </div>
                                            <div class="cart_item_total cart_info_col">
                                                <div class="cart_item_title">Total</div>
                                                <div class="cart_item_text">S/<?php echo e($item->qty*$item->price); ?></div>
                                            </div>
                                            <div class="cart_item_buttons cart_info_col">
                                                <div class="cart_item_title"></div>
                                                <div class="cart_item_text row ">
                                                    <form action="<?php echo e(route('cart.destroy',$item->rowId)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type="submit" class="btn btn-danger mx-2">
                                                            <i class="fa fa-trash bigfonts" aria-hidden="true"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <!-- Order Total -->
                        <div class="order_total">
                            <div class="order_total_content text-md-right">
                                <div class="row d-flex  justify-content-end" >
                                    <div class="col-md-4">
                                        <div class="order_total_title">Subtotal:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::subtotal()); ?></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="order_total_title">Impuesto:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::tax()); ?></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="order_total_title">Total del pedido:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::total()); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="cart_buttons row justify-content-between px-3">
                            <form action="<?php echo e(route('shop.index')); ?>" method="GET">
                                <button type="submit" class="button cart_button_clear ">Seguir comprando</button>
                            </form>
                            <form action="<?php echo e(route('cart.switchToSaveForLater',$item->rowId)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="button  cart_button_later">Guardar para más adelante</button>
                            </form>

                            <?php if(auth()->check()): ?>
                                <form action="<?php echo e(route('checkout.index')); ?>" method="GET">
                                    <button type="submit" class="button cart_button_checkout ">Enviar pedido</button>
                                </form>
                            <?php else: ?>
                                <a href="#" class="button cart_button_clear " data-toggle="modal" data-target="#LoginModal">Iniciar sesión para ordenar</a>

                            <?php endif; ?>

                        </div>
                    </div>
                    <?php else: ?>
                        <div class="alert alert-dark" role="alert">
                            <h3 class="text-center"> No hay artículos en el carrito!</h3>
                        </div>
                        <div class="cart_buttons row justify-content-center">
                            <form action="<?php echo e(route('shop.index')); ?>" method="get">
                                <button type="submit" class="button cart_button_clear ">Seguir comprando</button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <?php if(Cart::instance('saveForLater')->count() > 0): ?>

                        <h2 class="text-center mt-4"><?php echo e(Cart::instance('saveForLater')->count()); ?> artículo(s) guardado para más tarde</h2>

                        <div class="cart_items">
                            <ul class="cart_list">
                                <?php $__currentLoopData = Cart::instance('saveForLater')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cart_item clearfix">
                                        <div class="cart_item_image">
                                            <img src="<?php echo e(productImage($item->options->image)); ?>" alt="<?php echo e($item->name); ?>">
                                            

                                        </div>
                                        <div class="cart_item_info d-flex flex-md-row flex-column justify-content-between">
                                            <div class="cart_item_name cart_info_col">
                                                <div class="cart_item_title">Producto</div>
                                                <div class="cart_item_text"><?php echo e($item->name); ?></div>
                                            </div>
                                            <div class="cart_item_quantity cart_info_col">
                                                <div class="cart_item_title">Cantidad</div>
                                                <div class="cart_item_text"><?php echo e($item->qty); ?></div>
                                            </div>
                                            <div class="cart_item_price cart_info_col">
                                                <div class="cart_item_title">Precio</div>
                                                <div class="cart_item_text">S/<?php echo e($item->price); ?></div>
                                            </div>
                                            <div class="cart_item_total cart_info_col">
                                                <div class="cart_item_title">Total</div>
                                                <div class="cart_item_text">S/<?php echo e($item->qty*$item->price); ?></div>
                                            </div>
                                            <div class="cart_item_buttons cart_info_col">
                                                <div class="cart_item_title"></div>
                                                <div class="cart_item_text row">
                                                    <form action="<?php echo e(route('saveForLater.switchToCart',$item->rowId)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <button type="submit" class="btn btn-info mx-2">
                                                            <i class="fas fa-cart-plus bigfonts" aria-hidden="true"></i>
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('saveForLater.destroy',$item->rowId)); ?>" method="POST">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type="submit" class="btn btn-danger mx-2">
                                                            <i class="fa fa-trash bigfonts" aria-hidden="true"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <!-- Order Total -->
                        <div class="order_total">
                            <div class="order_total_content text-md-right">
                                <div class="row d-flex  justify-content-end" >
                                    <div class="col-md-3">
                                        <div class="order_total_title">Subtotal:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::subtotal()); ?></div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="order_total_title">Impuesto:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::tax()); ?></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="order_total_title">Total del pedido:</div>
                                        <div class="order_total_amount">S/<?php echo e(Cart::total()); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    <?php else: ?>
                        <div class="alert alert-dark" role="alert">
                            <h3 class="text-center"> No tiene artículos guardados para más tarde.</h3>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(asset('js/plantilla/cart_custom.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela_\PhpstormProjects\lista-ecommerce\resources\views/cart.blade.php ENDPATH**/ ?>