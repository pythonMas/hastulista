<!-- Modal -->
<div class="modal fade" id="RegisterModal" tabindex="-1" role="dialog" aria-labelledby="RegisterModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="RegisterModalLabel" class="text-center">Registrate y comienza a pedir.</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="input-group my-3">

                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <span class=" input-group-addon"><i class="fa fa-user "></i></span>
                                </div>
                            </div>


                            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="name" value="<?php echo e(old('name')); ?>"
                                   required autocomplete="name" autofocus placeholder="Nombre completo">

                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="input-group my-3">

                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <span class=" input-group-addon"><i class="fas fa-envelope"></i></span>
                                </div>
                            </div>


                            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="email" value="<?php echo e(old('email')); ?>"
                                   required autocomplete="email" placeholder="Dirección de correo electrónico">

                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="input-group my-3">

                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <span class=" input-group-addon"><i class="fas fa-lock"></i></span>
                                </div>
                            </div>

                            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> py-4" name="password"
                                   required autocomplete="new-password" placeholder="Contraseña">

                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="input-group my-3">

                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <span class=" input-group-addon"><i class="fas fa-check-circle"></i></span>
                                </div>
                            </div>

                            <input id="password-confirm" type="password" class="form-control py-4" name="password_confirmation" required autocomplete="new-password"
                                   placeholder="Confirmar contraseña">
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-12 ">
                                <button type="submit" class="btn btn-primary btn-block btn-lg">
                                    <?php echo e(__('Registrarme')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\vela_\PhpstormProjects\lista-ecommerce\resources\views/partials/auth/register.blade.php ENDPATH**/ ?>