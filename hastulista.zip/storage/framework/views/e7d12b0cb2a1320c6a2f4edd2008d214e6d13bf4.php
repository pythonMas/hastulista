<?php echo e($slot); ?>

<?php /**PATH C:\Users\USER\PhpstormProjects\lista-ecommerce\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>